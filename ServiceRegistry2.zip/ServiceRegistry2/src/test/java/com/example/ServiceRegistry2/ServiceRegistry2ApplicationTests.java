package com.example.ServiceRegistry2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistry2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
