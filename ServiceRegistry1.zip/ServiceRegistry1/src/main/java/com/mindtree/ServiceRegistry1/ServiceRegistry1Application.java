package com.mindtree.ServiceRegistry1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRegistry1Application {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRegistry1Application.class, args);
	}

}
