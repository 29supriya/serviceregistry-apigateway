package com.example.ApiGateWay2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGateWay2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiGateWay2Application.class, args);
	}

}
